package com.pyredevelopment.data;

public interface DataObject {



}
