package com.pyredevelopment.examples.regression;

import com.pyredevelopment.regression.LinearRegression;
import com.pyredevelopment.window.Plot;




/**
 * This class gives an example of simple Linear Regression using JLearn
 */
public class LinearRegressionExample {

    public static void main(String[] args) {

    }

}
