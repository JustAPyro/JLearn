module com.pyredevelopment {
    requires javafx.controls;
    requires com.pyredevelopment.regression;
    exports com.pyredevelopment.window;
    exports com.pyredevelopment.chart;
}