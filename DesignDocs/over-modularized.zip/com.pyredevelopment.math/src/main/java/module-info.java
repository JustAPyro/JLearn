module com.pyredevelopment.math {
    exports com.pyredevelopment.math.matrix;
}