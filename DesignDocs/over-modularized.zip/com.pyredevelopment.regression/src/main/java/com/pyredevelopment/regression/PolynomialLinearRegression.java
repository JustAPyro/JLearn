package com.pyredevelopment.regression;

public class PolynomialLinearRegression {


}
