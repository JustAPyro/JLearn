module com.pyredevelopment.regression {
    exports com.pyredevelopment.regression;
    requires com.pyredevelopment.math;
}