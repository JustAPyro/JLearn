package com.pyredevelopment.regression;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MultipleLinearRegressionTest {

    @Test
    @DisplayName("Testing a 2x10 perfect multiple linear regression")
    void test2x10MLR() {

    }

}